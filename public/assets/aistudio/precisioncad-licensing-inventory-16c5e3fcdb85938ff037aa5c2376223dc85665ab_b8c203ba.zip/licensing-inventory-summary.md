# PrecisionCAD Studio — Informational Licensing Inventory Summary

> Informational inventory only. Automated detection reports licence and copyright information observed in source files, package metadata and bundled materials. It does not select a project licence, determine legal obligations, evaluate compatibility, or decide whether a component may be used. Missing or ambiguous findings require separate human investigation; they are not legal conclusions.

## Scan Provenance & Completeness
- **Scan Status**: `INCOMPLETE`
- **Commit SHA**: `16c5e3fcdb85938ff037aa5c2376223dc85665ab`
- **Branch / Ref**: `main`
- **Timestamp (UTC)**: `2026-11-03T01:54:31Z`
- **Scanner Versions**: Python `3.12.3`, ScanCode `not-installed (used built-in Repository File Inspector)`, CycloneDX `1.5`

## Inventory Counts
- **Total Dependency Records (Across Resolved Configurations)**: `756`
  - Direct records: `61`
  - Transitive records: `695`
- **Repository Files Scanned**: `97`
- **Files with Detected Licence Identifier**: `2`
- **Files with Detected Copyright Notice**: `2`
- **Distinct Observed Licence Strings**: `Apache-2.0`
- **Records with Multiple / Ambiguous Findings**: `0`
- **Records with No Licence Information Detected (`NOT_DETECTED` / `UNKNOWN_METADATA`)**: `275`
- **Excluded / Skipped Inputs**: `1`

## Dependency Records by Gradle Configuration
- `buildscript:classpath`: `170`
- `debugCompileClasspath`: `116`
- `debugRuntimeClasspath`: `136`
- `kspDebugKotlinProcessorClasspath`: `46`
- `kspReleaseKotlinProcessorClasspath`: `46`
- `releaseCompileClasspath`: `111`
- `releaseRuntimeClasspath`: `131`

## Omitted / Incomplete Inputs
- `testDebugUnitTestRuntimeClasspath (rc=1)`
- `testDebugUnitTestCompileClasspath (rc=1)`
- `scancode CLI exited with 1: Traceback (most recent call last):
  File "/home/runner/.local/bin/scancode", line 3, in <module>
    from scancode.cli import scancode
  File "/home/runner/.local/lib/python3.12/site-packages/scancod`

## Generated Report Files
- `dependency-bom.cdx.json` (CycloneDX 1.5 JSON SBOM)
- `dependency-bom.cdx.xml` (CycloneDX 1.5 XML SBOM)
- `scancode-source-inventory.json` (File-level raw JSON inventory)
- `scancode-source-inventory.csv` (Combined tabular CSV inventory)
- `licensing-inventory.html` (Human-readable combined HTML report)
- `licensing-inventory-summary.md` (Markdown summary)
- `licensing-inventory-status.json` (Provenance & completeness status)
- `gradle-build-logic-dependencies.txt` (Gradle plugin & buildscript dependencies)
