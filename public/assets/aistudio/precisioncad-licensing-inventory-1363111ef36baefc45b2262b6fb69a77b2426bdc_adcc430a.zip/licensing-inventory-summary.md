# PrecisionCAD Studio — Informational Licensing Inventory Summary

> Informational inventory only. Automated detection reports licence and copyright information observed in source files, package metadata and bundled materials. It does not select a project licence, determine legal obligations, evaluate compatibility, or decide whether a component may be used. Missing or ambiguous findings require separate human investigation; they are not legal conclusions.

## Scan Provenance & Completeness
- **Scan Completeness**: `INCOMPLETE`
- **ScanCode Status**: `VERSION_CHECK_FAILED` (version: `not-installed`, exitCode: `None`)
- **Application ID**: `com.precisioncad.studio`
- **Effective Application Version**: `1.18.1.2` (`versionCode=21`)
- **Commit SHA**: `1363111ef36baefc45b2262b6fb69a77b2426bdc`
- **Branch / Ref**: `main`
- **Timestamp (UTC)**: `2026-11-03T04:54:26Z`
- **Toolchain**: Gradle `9.3.1`, AGP `9.1.1`, Kotlin `2.4.21`, KSP `2.3.13`, JDK `openjdk version "21.0.13" 2026-10-20 LTS`

## Dependency & Component Counts
- **Unique Resolved Maven Components (Deduplicated by PURL)**: `379`
  - Unique direct components: `105`
  - Unique transitive-only components: `274`
  - Buildscript / plugin components: `167`
  - Test-only components: `56`
  - Unique components with exact POM licence declaration: `208`
- **Total Configuration-Level Dependency Records**: `1436` (Direct: `196`, Transitive: `1240`)

## Repository Source & Bundled Asset Counts
- **Repository Files Scanned (In-Scope)**: `101` (ScanCode files merged: `0`)
- **Files with Detected Licence Identifier**: `2`
- **Files with Detected Copyright Notice**: `2`
- **Distinct Observed Licence Identifiers (Exact POM + Source Headers)**: `Apache-2.0, BSD-3-Clause, EPL-1.0, MIT`
- **Records with Multiple / Ambiguous Findings**: `8`
- **Records with No Licence / Unknown Metadata (`NOT_DETECTED` / `UNKNOWN_METADATA`)**: `291`
- **Intentional Policy Exclusions**: `6`
- **Unexpected Read / Configuration Failures**: `0`

## Dependency Records by Resolved Gradle Configuration
- `buildscript:classpath`: `170`
- `debugAndroidTestCompileClasspath`: `140`
- `debugAndroidTestRuntimeClasspath`: `188`
- `debugCompileClasspath`: `116`
- `debugRuntimeClasspath`: `136`
- `debugUnitTestCompileClasspath`: `161`
- `debugUnitTestRuntimeClasspath`: `191`
- `kspDebugKotlinProcessorClasspath`: `46`
- `kspReleaseKotlinProcessorClasspath`: `46`
- `releaseCompileClasspath`: `111`
- `releaseRuntimeClasspath`: `131`

## Incomplete Stages & Diagnostics
- **ScanCode CLI**: status=`VERSION_CHECK_FAILED`, version=`not-installed`, diagnostic=`diagnostics/scancode-install.log`

## Generated Report Files
- `dependency-bom.cdx.json` (CycloneDX 1.5 JSON SBOM with dynamic app version and exact POM evidence)
- `dependency-bom.cdx.xml` (CycloneDX 1.5 XML SBOM)
- `scancode-raw.json` (Genuine unmodified ScanCode JSON; present only when ScanCode CLI executes)
- `repository-file-inspector.json` (Lightweight built-in SHA-256 and SPDX/copyright header inspector output)
- `licensing-inventory.csv` (Consolidated dependency and file-level CSV inventory)
- `licensing-inventory.html` (Human-readable combined HTML report)
- `licensing-inventory-summary.md` (Concise Markdown summary)
- `licensing-inventory-status.json` (Machine-readable provenance and completeness status)
- `gradle-build-logic-dependencies.txt` (Gradle plugin & buildscript dependencies)
- `diagnostics/` (Full untruncated Gradle and ScanCode stdout/stderr logs)
